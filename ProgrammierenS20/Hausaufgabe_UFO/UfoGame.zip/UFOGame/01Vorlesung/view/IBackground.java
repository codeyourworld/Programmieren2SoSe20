  package view;

public interface IBackground {

	public String getImagePath();

}
