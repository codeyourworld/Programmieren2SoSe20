package view;

public interface IBlock {

}
