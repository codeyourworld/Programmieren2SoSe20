package view;

public interface IAnimatedObject {

	public String[] getImagePaths();
	public int getUpdateTime();
}
