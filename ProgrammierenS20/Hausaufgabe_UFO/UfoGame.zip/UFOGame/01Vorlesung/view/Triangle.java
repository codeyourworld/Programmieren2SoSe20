package view;

import java.awt.Color;

public class Triangle extends Shape {

	public Triangle(int x, int y, int width, int height, Color color) {
		super(x, y, width, height, color);
	}
}
