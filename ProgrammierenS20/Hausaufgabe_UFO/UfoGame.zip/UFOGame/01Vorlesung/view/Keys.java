package view;

public enum Keys {

	KEY_ARROW_UP,
	KEY_ARROW_DOWN,
	KEY_ARROW_LEFT,
	KEY_ARROW_RIGHT,
	KEY_SPACE,
	KEY_ENTER,
	KEY_A, 
	KEY_S, 
	KEY_D, 
	KEY_E,
	KEY_W,
	KEY_Q,
	KEY_ESC
	
}
