package view;
import java.awt.Color;

public class Oval extends Shape{
	
	public Oval(int x, int y, int width, int height, Color color) {
		super(x, y, width, height, color);
	}

}
