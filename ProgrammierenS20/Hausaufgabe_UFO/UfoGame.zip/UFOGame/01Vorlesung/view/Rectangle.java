package view;
import java.awt.Color;

public class Rectangle extends Shape{

	public Rectangle(int x, int y, int width, int height, Color color) {
		super(x, y, width, height, color);
	}
}
