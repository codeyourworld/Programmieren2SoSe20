package ufogame;

public class GameMain {

	public static void main(String[] args) {
		Game game = new Game();
		game.init();
	}
}
